<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}


// Inclure la connexion à la base de données
require_once 'db_connection.php';
?>
<?php
// Inclure le fichier de configuration de la base de données
include_once("config.php");

// Vérifier si le formulaire est soumis
if (isset($_POST['add'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $statut = $_POST['statut'];

    // Validation des champs obligatoires
    if (empty($username) || empty($password) || empty($statut)) {
        echo "<font color='red'>Tous les champs marqués * sont obligatoires.</font><br/>";
    } else {
        // Hachage du mot de passe avant l'insertion
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Préparer la requête SQL pour insérer l'utilisateur
        $stmt = $bdd->prepare("INSERT INTO user (username, password, statut) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hashedPassword, $statut);

        // Exécution de la requête
        if ($stmt->execute()) {
            // Si le statut est 'Admin', insérer l'utilisateur dans la table 'admin'
            if ($statut == 'Admin') {
                // Insérer l'utilisateur dans la table 'admin'
                $stmtAdmin = $bdd->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
                $stmtAdmin->bind_param("ss", $username, $hashedPassword);
                $stmtAdmin->execute();
                $stmtAdmin->close();
            }

            // Fermeture de la déclaration préparée
            $stmt->close();

            // Redirection en cas de succès
            header("Location: index.php?message=Utilisateur ajouté avec succès");
            exit;
        } else {
            echo "<font color='red'>Erreur lors de l'ajout : " . mysqli_error($bdd) . "</font>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Utilisateur</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
            margin: 20px auto;
        }

        .form-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .form-container input, .form-container select {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: rgb(0, 0, 0);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgb(255, 0, 0);
        }

        a {
            color: black;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h2>Ajouter un Nouvel Utilisateur</h2>
    <form method="post" action="add.php" class="form-container">
        <label for="username">Nom d'utilisateur *</label>
        <input type="text" name="username" required>

        <label for="password">Mot de passe *</label>
        <input type="password" name="password" required>

        <label for="statut">Statut *</label>
        <select name="statut" required>
            <option value="Admin">Admin</option>
            <option value="Utilisateur">Utilisateur</option>
        </select>

        <button type="submit" name="add">Ajouter</button>
        <button type="button" onclick="window.location.href='index.php';">Retour</button>
    </form>
</body>
</html>
