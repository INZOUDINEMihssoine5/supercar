<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}


// Inclure la connexion à la base de données
require_once 'db_connection.php';
?>
<?php
// Inclusion du fichier de connexion à la base de données
include_once("config.php");

if (isset($_POST['update'])) {
    $id = intval($_POST['id']); // Convertir l'ID en entier pour plus de sécurité
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $statut = $_POST['statut']; // Capturer le statut du formulaire

    // Vérifier si le champ du nom d'utilisateur est vide
    if (empty($username)) {
        echo "<font color='red'>Le champ du nom d'utilisateur est vide.</font><br/>";
    } else {
        // Si un mot de passe est fourni, le mettre directement dans la base de données ; sinon, garder le mot de passe actuel
        if (!empty($password)) {
            // Ne pas hacher le mot de passe, on le garde en texte clair
            $newPassword = $password;
        } else {
            // Récupérer le mot de passe existant depuis la base de données si aucun nouveau mot de passe n'est fourni
            $result = $bdd->prepare("SELECT password FROM user WHERE id = ?");
            $result->bind_param("i", $id);
            $result->execute();
            $result->bind_result($newPassword);
            $result->fetch();
            $result->close();
        }

        // Utiliser une déclaration préparée pour mettre à jour l'utilisateur
        $stmt = $bdd->prepare("UPDATE user SET username = ?, password = ?, statut = ? WHERE id = ?");
        $stmt->bind_param("sssi", $username, $newPassword, $statut, $id); // Lier le statut

        if ($stmt->execute()) {
            // Si le statut est 'Admin', insérer l'utilisateur dans la table 'admin'
            if ($statut == 'Admin') {
                // Insérer l'utilisateur dans la table 'admin'
                $stmtAdmin = $bdd->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
                $stmtAdmin->bind_param("ss", $username, $newPassword);
                $stmtAdmin->execute();
                $stmtAdmin->close();
            }
            // Rediriger vers la page d'affichage
            header("Location: index.php");
            exit();
        } else {
            echo "<font color='red'>Erreur lors de la mise à jour : " . $stmt->error . "</font><br/>";
        }

        $stmt->close();
    }
}

// Récupérer les données de l'utilisateur basé sur l'ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $bdd->prepare("SELECT username, statut FROM user WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($username, $statut); // Récupérer également le statut
    $stmt->fetch();
    $stmt->close();
} else {
    echo "<font color='red'>ID invalide.</font><br/>";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Édition de l'utilisateur</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0, 0, 0);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn:hover {
            background-color: rgb(255, 0, 0);
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: rgb(0, 0, 0);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgb(255, 0, 0);
        }

        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            margin: 20px auto;
        }

        .login-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
        }

        a {
            color: black;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form name="form1" method="post" action="edit.php">
        <table border="0">
            <tr>
                <td>Nom d'utilisateur</td>
                <td><input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>"></td>
            </tr>
            <tr>
                <td>Mot de passe</td>
                <td>
                    <input type="password" name="password" placeholder="Entrez un nouveau mot de passe">
                    <br><small>Laisser vide pour conserver le mot de passe actuel</small>
                </td>
            </tr>
            <tr>
                <td>Statut</td>
                <td>
                    <select name="statut">
                        <option value="Utilisateur" <?php echo ($statut == 'Utilisateur') ? 'selected' : ''; ?>>Utilisateur</option>
                        <option value="Admin" <?php echo ($statut == 'Admin') ? 'selected' : ''; ?>>Admin</option>
                    </select>
                </td>
            </tr>
        </table>
        <input type="hidden" name="id" value="<?php echo intval($_GET['id']); ?>">
        <button type="submit" name="update">Mettre à jour</button>
        <button type="button" onclick="location.href='index.php'">Retour</button>
    </form>
</body>
</html>
