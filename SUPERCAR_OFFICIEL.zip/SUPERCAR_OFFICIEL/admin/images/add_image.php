<?php
session_start();

// Vérification de la session pour l'administrateur
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

// Inclure la connexion à la base de données
require_once 'db_connection.php';

// Vérification de l'envoi du formulaire
if (isset($_POST['upload'])) {
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        
        // Récupération des informations du fichier
        $imageName = $_FILES['image']['name'];
        $imageTmpName = $_FILES['image']['tmp_name'];
        $imageType = $_FILES['image']['type'];
        $imageSize = $_FILES['image']['size'];
        $modele = $_POST['modele'];
        
        
        // Validation de la taille du fichier (par exemple 5 Mo maximum)
        if ($imageSize > 5 * 1024 * 1024) {
            echo "La taille du fichier est trop grande. La taille maximale autorisée est 5 Mo.";
            exit();
        }

        // Lire l'image en binaire
        $imageData = file_get_contents($imageTmpName);

        // Préparation de la requête d'insertion
        $stmt = $db->prepare("INSERT INTO images (nom, type, image, modele) VALUES (?, ?, ?, ?)");
        $stmt->execute([$imageName, $imageType, $imageData, $modele]);

        // Rediriger vers la page de gestion des images après l'upload
        header("Location: gestion_images.php");
        exit();
    } else {
        echo "Erreur lors de l'upload de l'image.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Image</title>
</head>
<body>

    <h2>Ajouter une image</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <label for="image">Sélectionner une image :</label>
        <input type="file" name="image" id="image" required><br><br>
        
        <label for="modele">Modèle :</label>
        <input type="text" name="modele" id="modele" required><br><br>
        
        <input type="submit" name="upload" value="Uploader">
    </form>

</body>
</html>
