<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

require_once 'db_connection.php';

if (isset($_GET['id'])) {
    $imageId = $_GET['id'];

    // Supprimer l'image en fonction de l'id
    $stmt = $db->prepare("DELETE FROM images WHERE id = ?");
    $stmt->execute([$imageId]);

    header("Location: gestion_images.php");
    exit();
}
?>
