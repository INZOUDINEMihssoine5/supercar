<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}

// Inclure la connexion à la base de données
require_once 'db_connection.php';

// Inclusion du fichier de configuration pour la connexion à la base de données
include_once("config.php");

// Mise à jour des données
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nom = $_POST['nom'];
    $modele = $_POST['modele'];
    $type = $_POST['type']; // Nouveau champ 'type'

    // Gestion de l'image si une nouvelle est téléchargée
    if (isset($_FILES['image']['tmp_name']) && !empty($_FILES['image']['tmp_name'])) {
        $imageData = addslashes(file_get_contents($_FILES['image']['tmp_name']));
        $query = "UPDATE images SET nom='$nom', image='$imageData', modele='$modele', type='$type' WHERE id=$id";
    } else {
        // Mise à jour sans changer l'image
        $query = "UPDATE images SET nom='$nom', modele='$modele', type='$type' WHERE id=$id";
    }

    if (mysqli_query($bdd, $query)) {
        header("Location: gestion_images.php");
    } else {
        echo "<font color='red'>Erreur lors de la mise à jour : " . mysqli_error($bdd) . "</font>";
    }
}

// Récupération des données pour une entrée spécifique
$id = $_GET['id'];
$result = mysqli_query($bdd, "SELECT * FROM images WHERE id=$id");
$data = mysqli_fetch_assoc($result);

// Vérification si une image existe
$image = !empty($data['image']) ? base64_encode($data['image']) : null;
?>

<!DOCTYPE html>
<html lang="fr">
<head>    
    <title>Modifier une entrée</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container, .form-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .btn, button {
            background-color: #333;
            color: white;
            border-radius: 5px;
            padding: 10px 20px;
            transition: background-color 0.3s;
        }

        .btn:hover, button:hover {
            background-color: #ff0000;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
    </style>
</head>
<body>

<form name="form1" method="post" action="edit_image.php" enctype="multipart/form-data">
    <table border="1" width="80%">
        <tr> 
            <td>Nom</td>
            <td><input type="text" name="nom" value="<?php echo htmlspecialchars($data['nom']); ?>"></td>
        </tr>
        <tr> 
            <td>Modèle</td>
            <td><input type="text" name="modele" value="<?php echo htmlspecialchars($data['modele']); ?>"></td>
        </tr>
        <tr>
            <td>Type</td>
            <td><input type="text" name="type" value="<?php echo htmlspecialchars($data['type']); ?>"></td>
        </tr>
        <tr>
            <td>Image actuelle</td>
            <td><?php if ($image): ?><img src="data:image/jpeg;base64,<?php echo $image; ?>" alt="Image actuelle" width="100"><?php else: ?>Aucune image<?php endif; ?></td>
        </tr>
        <tr>
            <td>Nouvelle Image</td>
            <td><input type="file" name="image"></td>
        </tr>
        <tr>
            <td><input type="hidden" name="id" value="<?php echo $data['id']; ?>"></td>
            <td><input type="submit" name="update" value="Mettre à jour"></td>
        </tr>
    </table>
</form>

<h2>Administration des Images</h2>

<table border="1" width="80%">
    <tr>
        <th>ID</th>
        <th>Nom</th>
        <th>Modèle</th>
        <th>Type</th>
        <th>Image</th>
        <th>Actions</th>
    </tr>
    <?php
    $resultImages = mysqli_query($bdd, "SELECT * FROM images");
    if (mysqli_num_rows($resultImages) > 0) {
        while ($row = mysqli_fetch_assoc($resultImages)) {
            $imageId = $row['id'];
            $nom = htmlspecialchars($row['nom']);
            $modele = htmlspecialchars($row['modele']);
            $type = htmlspecialchars($row['type']);
            $imageBlob = !empty($row['image']) ? base64_encode($row['image']) : null;

            echo "<tr>";
            echo "<td>$imageId</td>";
            echo "<td>$nom</td>";
            echo "<td>$modele</td>";
            echo "<td>$type</td>";
            echo "<td>";
            echo $imageBlob ? "<img src='data:image/jpeg;base64,$imageBlob' alt='Image $imageId' width='100'>" : "Aucune image";
            echo "</td>";
            echo "<td><a href='edit_image.php?id=$imageId'>Modifier</a> | <a href='delete_image.php?id=$imageId' onclick='return confirm(\"\u00cates-vous sûr de vouloir supprimer cette image ?\")'>Supprimer</a></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>Aucune image trouvée.</td></tr>";
    }
    ?>
</table>

<button type="button" onclick="window.location.href='gestion_images.php';">Retour</button>

</body>
</html>
