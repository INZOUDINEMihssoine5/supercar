<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

// Vérifie si l'administrateur est connecté, sinon redirige vers la page de connexion
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php"); // Redirection vers la page de connexion admin
    exit();  // Arrête l'exécution du script après la redirection
}

// Inclut le fichier de connexion à la base de données (utilisant PDO)
require_once 'db_connection.php';
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Images</title>
    <style>
        /* Styles CSS pour améliorer l'apparence de la page */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .btn, button {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0, 0, 0);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
            border: none;
            cursor: pointer;
        }

        .btn:hover, button:hover {
            background-color: rgb(255, 0, 0);
        }
    </style>
</head>

<body>

<h2>Gestion des Images</h2>

<div class="container">
    <!-- Formulaire pour ajouter une nouvelle image -->
    <form action="add_image.php" method="post" enctype="multipart/form-data">
        <label for="image">Choisir une image à uploader :</label>
        <input type="file" name="image" id="image" required><br><br>
        
        <label for="modele">Modèle de l'image :</label>
        <input type="text" name="modele" id="modele" required><br><br>

        <label for="type">Type :</label>
        <input type="text" name="type" id="type" required><br><br>

        <button type="submit" name="upload">Ajouter</button>
    </form>
</div>

<h2>Liste des Images</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Type</th> 
        <th>Nom</th>
        <th>Modèle</th>
        <th>Image</th>
        <th>Actions</th>
    </tr>
    <?php
    // Requête SQL pour récupérer toutes les images de la base de données
    $stmtImages = $db->prepare("SELECT * FROM images");
    $stmtImages->execute();
    $resultImages = $stmtImages->fetchAll(PDO::FETCH_ASSOC);

    // Affiche les images si elles existent
    if (count($resultImages) > 0) {
        foreach ($resultImages as $row) {
            $imageId = $row['id'];
            $nom = htmlspecialchars($row['nom']); // Protège contre les injections XSS
            $modele = htmlspecialchars($row['modele']);
            $type = htmlspecialchars($row['type']);
            $imageBlob = !empty($row['image']) ? base64_encode($row['image']) : null;

            echo "<tr>";
            echo "<td>" . $imageId . "</td>";
            echo "<td>" . $type . "</td>";
            echo "<td>" . $nom . "</td>";
            echo "<td>" . $modele . "</td>";
            echo "<td>";
            if ($imageBlob) {
                // Affiche l'image encodée en base64
                echo "<img src='data:image/jpeg;base64,$imageBlob' alt='Image $imageId' width='100'>";
            } else {
                echo "Aucune image";
            }
            echo "</td>";
            echo "<td>
                    <a href='edit_image.php?id=$imageId'>Modifier</a> |
                    <a href='delete_image.php?id=$imageId' onclick='return confirm(\"Êtes-vous sûr de vouloir supprimer cette image ?\")'>Supprimer</a>
                  </td>";
            echo "</tr>";
        }
    } else {
        // Message affiché s'il n'y a pas d'images
        echo "<tr><td colspan='6'>Aucune image trouvée.</td></tr>";
    }
    ?>
</table>

<br><br>

<!-- Bouton de retour vers le tableau de bord -->
<button onclick="window.location.href='../dashboard.php';">Retour</button>

</body>
</html>
