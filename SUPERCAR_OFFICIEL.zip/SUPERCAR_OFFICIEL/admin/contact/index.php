<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}

// Inclure la connexion à la base de données
require_once 'db_connection.php';
?>
<?php
// Including the database connection file
include_once("config.php");

// Fetching data in ascending order (earliest entry first)
$result = mysqli_query($bdd, "SELECT * FROM form ORDER BY id ASC"); 
?>

<html>
<head>    
    <title>Administration des Données</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        /* Styles pour les tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Styles pour les boutons */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0, 0, 0);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn:hover {
            background-color: rgb(255, 0, 0);
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: rgb(0, 0, 0);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgb(255, 0, 0);
        }

        /* Formulaire de connexion */
        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            margin: 20px auto;
        }

        .login-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
        }

        /* Lien stylé */
        a {
            color: black;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <h2>Administration des Données de Formulaire</h2>

    <table width="80%" border="1">
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Objet</th>
            <th>Message</th>
            <th>Actions</th>
        </tr>

        <?php 
        // Fetching each row of data from the 'form' table
        while ($res = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $res['id'] . "</td>";
            echo "<td>" . htmlspecialchars($res['nom']) . "</td>";
            echo "<td>" . htmlspecialchars($res['email']) . "</td>";
            echo "<td>" . htmlspecialchars($res['phone']) . "</td>";
            echo "<td>" . htmlspecialchars($res['objet']) . "</td>";
            echo "<td>" . htmlspecialchars($res['message']) . "</td>";
            echo "<td>
                    <a href='edit.php?id=" . $res['id'] . "' class='btn'>Modifier</a> | 
                    <a href='delete.php?id=" . $res['id'] . "' class='btn' onclick='return confirm(\"Voulez-vous vraiment supprimer cette entrée ?\")'>Supprimer</a>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>

    <div class="text-center">
        <button type="button" onclick="window.location.href='../dashboard.php';">Retour au Tableau de Bord</button>
    </div>

</body>
</html>
