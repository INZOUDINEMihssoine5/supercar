<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['admin'])) {
    // Rediriger vers la page de connexion si non connecté
    $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI']; // Sauvegarder la page actuelle
    header("Location: ../admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord : Services</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #f0f0f5, #e0e0ff);
        }

        header {
            background-color: black;
            color: white;
            padding: 10px 20px;
            text-align: center;
        }

        nav {
            margin: 20px;
            text-align: center;
        }

        nav a {
            text-decoration: none;
            color: black;
            margin: 0 15px;
            font-weight: bold;
        }

        nav a:hover {
            color: #FF0000;
        }

        h2 {
            text-align: center;
            margin: 20px 0;
        }

        .button-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 50px;
        }

        .button {
            width: 200px;
            height: 100px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 18px;
            text-decoration: none;
            color: white;
            background-color: black;
            border-radius: 15px;
            text-align: center;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .button:hover {
            background-color: #FF0000;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
<header>
    <h1>Bienvenue dans le Tableau de Bord : Services <br/> <?php echo htmlspecialchars($_SESSION['admin']); ?></h1>
</header>
<nav>


<a href='../dashboard.php';>Retour</a> 

    
</nav>
<div class="button-container">
    <a href="manage_rdv.php" class="button">Gérer Rendez-Vous</a>
    <a href="manage_devis.php" class="button">Gérer Demande de Devis</a>
    <a href="manage_reprise.php" class="button">Gérer Reprise de Véhicules</a>
    <a href="manage_promotions.php" class="button">Gérer Promotions</a> 
</div>

</body>
</html>
