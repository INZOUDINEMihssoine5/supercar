<?php
session_start();


// Vérifier si l'utilisateur est déjà connecté
if (!isset($_SESSION['user_authenticated']) || $_SESSION['user_authenticated'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $serveur = "localhost";
        $utilisateur = "root";
        $mot_de_passe = "";
        $base_de_donnees = "supercar";

        // Connexion à la base de données
        $connexion = new mysqli($serveur, $utilisateur, $mot_de_passe, $base_de_donnees);

        // Vérification de la connexion
        if ($connexion->connect_error) {
            die("Échec de la connexion à la base de données : " . $connexion->connect_error);
        }

        // Échapper les entrées utilisateur pour éviter les injections SQL
        $username = $connexion->real_escape_string($_POST['username']);
        $password = $connexion->real_escape_string($_POST['password']);

        // Requête SQL pour vérifier les identifiants
        $requete = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
        $resultat = $connexion->query($requete);

        if ($resultat->num_rows > 0) {
            // Connexion réussie
            $_SESSION['user_authenticated'] = true;
            $_SESSION['admin'] = $username;

    
            // Redirection après connexion
            header("Location: " . ($_SESSION['redirect_to'] ?? 'vlc_RESTRICTED.php'));
            exit();
        } else {
            // Identifiants incorrects
            $error_message = "Nom d'utilisateur ou mot de passe incorrect.";
        }

        $connexion->close();
    }

    // Affichage du formulaire de connexion si non authentifié
    ?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Connexion Administrateur</title>
        <style>
            body {
                font-family: 'Arial', sans-serif;
                background-color: #f4f4f9;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }

            h2 {
                color: #333;
                margin-bottom: 20px;
            }

            .login-container {
                background-color: #ffffff;
                padding: 40px;
                border-radius: 8px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                width: 100%;
                max-width: 400px;
                text-align: center;
            }

            .login-container label {
                display: block;
                font-size: 14px;
                margin-bottom: 5px;
                text-align: left;
                margin-left: 10px;
            }

            .login-container input {
                width: 100%;
                padding: 12px;
                margin: 10px 0 20px;
                border: 1px solid #ddd;
                border-radius: 5px;
                box-sizing: border-box;
                font-size: 16px;
            }

            .login-container button {
                width: 100%;
                padding: 12px;
                background-color: rgb(0, 0, 0);
                border: none;
                border-radius: 5px;
                color: white;
                font-size: 16px;
                cursor: pointer;
                transition: background-color 0.3s;
            }

            .login-container button:hover {
                background-color: rgb(255, 0, 0);
            }

            .error-message {
                color: red;
                margin-bottom: 20px;
            }

            .login-container a {
                color: white;
                text-decoration: none;
                font-size: 14px;
                display: block;
                margin-top: 10px;
            }

            .login-container a:hover {
                text-decoration: underline;
            }
        </style>
    </head>
    <body>
    <div class="login-container">
        <h2>Connexion Requise</h2>
        <?php if (!empty($error_message)) echo "<p class='error-message'>$error_message</p>"; ?>
        <form action="" method="post">
            <label for="username">Nom d'utilisateur :</label>
            <input type="text" name="username" id="username" required>
            
            <label for="password">Mot de passe :</label>
            <input type="password" name="password" id="password" required>
            
            <button type="submit">Se connecter</button>
            <button> <a href="dasboard.php">Quitter</a></button>
        </form>
    </div>
    </body>
    </html>
    <?php
    exit();
}

// Code de la page principale
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Connexions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            padding: 20px;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0, 0, 0);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: rgb(255, 0, 0);
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Liste des Connexions</h1>
    <?php
    $connexion = new mysqli("localhost", "root", "", "supercar");

    if ($connexion->connect_error) {
        die("<p>Échec de la connexion à la base de données : " . $connexion->connect_error . "</p>");
    }

    $sql = "SELECT username, connection_time FROM connections ORDER BY connection_time DESC";
    $result = $connexion->query($sql);

    if ($result && $result->num_rows > 0) {
        echo "<table>
                <thead>
                    <tr>
                        <th>Nom d'utilisateur</th>
                        <th>Heure de connexion</th>
                    </tr>
                </thead>
                <tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['username']) . "</td>
                    <td>" . htmlspecialchars($row['connection_time']) . "</td>
                  </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p>Aucune connexion enregistrée.</p>";
    }

    $connexion->close();
    ?>
    <a href="../dashboard.php" class="btn">Retour au tableau de bord</a>
</div>
</body>
</html>
