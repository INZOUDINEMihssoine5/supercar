<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}
// Inclure la connexion à la base de données
require_once 'db_connection.php';

// Gestion des données soumises par le formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['update'])) {
    // Récupérer les données du formulaire d'ajout
    $sexe = $_POST['sexe'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $telephone = $_POST['telephone'];
    $mail = $_POST['mail'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $code_postal = $_POST['code_postal'];
    $voiture = $_POST['voiture'];
    $maintenance = $_POST['maintenance'];
    $date = $_POST['date'];
    $description = $_POST['description'];

    // Préparation et exécution de la requête d'insertion pour le rendez-vous
    $query = $db->prepare("INSERT INTO rdv (sexe, nom, prenom, telephone, mail, adresse, ville, code_postal, voiture, maintenance, date, description) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $query->execute([$sexe, $nom, $prenom, $telephone, $mail, $adresse, $ville, $code_postal, $voiture, $maintenance, $date, $description]);

    // Message de confirmation
    $_SESSION['message'] = "Rendez-vous ajouté avec succès.";
    // Redirection pour éviter la soumission multiple
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Gestion de la suppression d'un rendez-vous
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id_rdv = $_GET['delete'];

    // Préparation et exécution de la requête de suppression
    $query = $db->prepare("DELETE FROM rdv WHERE id = ?");
    $query->execute([$id_rdv]);

    // Message de confirmation
    $_SESSION['message'] = "Rendez-vous supprimé avec succès.";
    // Redirection après suppression
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Gestion de la mise à jour d'un rendez-vous
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $id_rdv = $_GET['edit'];

    // Récupérer les informations du rendez-vous pour l'afficher dans le formulaire
    $query = $db->prepare("SELECT * FROM rdv WHERE id = ?");
    $query->execute([$id_rdv]);
    $rdv = $query->fetch();

    if (!$rdv) {
        $_SESSION['message'] = "Rendez-vous introuvable.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Mise à jour du rendez-vous
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $id = $_POST['id'];  // ID du rendez-vous
    $sexe = $_POST['sexe'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $telephone = $_POST['telephone'];
    $mail = $_POST['mail'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $code_postal = $_POST['code_postal'];
    $voiture = $_POST['voiture'];
    $maintenance = $_POST['maintenance'];
    $date = $_POST['date'];
    $description = $_POST['description'];

    // Mise à jour du rendez-vous
    $query = $db->prepare("UPDATE rdv SET sexe = ?, nom = ?, prenom = ?, telephone = ?, mail = ?, adresse = ?, ville = ?, code_postal = ?, voiture = ?, maintenance = ?, date = ?, description = ? WHERE id = ?");
    $query->execute([$sexe, $nom, $prenom, $telephone, $mail, $adresse, $ville, $code_postal, $voiture, $maintenance, $date, $description, $id]);

    // Message de confirmation
    $_SESSION['message'] = "Rendez-vous mis à jour avec succès.";
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Récupérer tous les rendez-vous existants
$query = $db->query("SELECT * FROM rdv");
$rdvs = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer Rendez-vous Maintenance</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        /* Styles pour les tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Styles pour les boutons */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0, 0, 0);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn:hover {
            background-color: rgb(255, 0, 0);
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: rgb(0, 0, 0);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgb(255, 0, 0);
        }

        /* Formulaire de connexion */
        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            margin: 20px auto;
        }

        .login-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
        }

        /* Lien stylé */
        a {
            color: black;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <h3>Rendez-vous Existants</h3>
    <table>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Téléphone</th>
                <th>Voiture</th>
                <th>Maintenance</th>
                <th>Date du rendez-vous</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rdvs as $rdv): ?>
                <tr>
                    <td><?php echo htmlspecialchars($rdv['nom']); ?></td>
                    <td><?php echo htmlspecialchars($rdv['prenom']); ?></td>
                    <td><?php echo htmlspecialchars($rdv['telephone']); ?></td>
                    <td><?php echo htmlspecialchars($rdv['voiture']); ?></td>
                    <td><?php echo htmlspecialchars($rdv['maintenance']); ?></td>
                    <td><?php echo htmlspecialchars($rdv['date']); ?></td>
                    <td><?php echo htmlspecialchars($rdv['description']); ?></td>
                    <td>
                        <a href="?edit=<?php echo $rdv['id']; ?>"><button>Modifier</button></a>
                        <a href="?delete=<?php echo $rdv['id']; ?>" onclick="return confirm('Voulez-vous vraiment supprimer ce rendez-vous ?');">
                            <button class="btn-delete">Supprimer</button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php
    // Si un ID de demande est passé pour modification
    if (isset($_GET['edit'])) {
        $id_rdv = $_GET['edit'];

        // Récupérer les détails du rendez-vous à modifier
        $query = $db->prepare("SELECT * FROM rdv WHERE id = ?");
        $query->execute([$id_rdv]);
        $rdv = $query->fetch();

        // Si le rendez-vous existe, afficher le formulaire pré-rempli
        if ($rdv) {
            ?>
            <h3>Modifier le Rendez-vous</h3>
            <form action="" method="POST">
                <input type="hidden" name="id" value="<?php echo $rdv['id']; ?>">

                <label for="sexe">Sexe :</label>
                <select name="sexe" id="sexe" required>
                    <option value="Homme" <?php echo ($rdv['sexe'] == 'Homme') ? 'selected' : ''; ?>>Homme</option>
                    <option value="Femme" <?php echo ($rdv['sexe'] == 'Femme') ? 'selected' : ''; ?>>Femme</option>
                </select>

                <label for="nom">Nom :</label>
                <input type="text" name="nom" id="nom" value="<?php echo htmlspecialchars($rdv['nom']); ?>" required>

                <label for="prenom">Prénom :</label>
                <input type="text" name="prenom" id="prenom" value="<?php echo htmlspecialchars($rdv['prenom']); ?>" required>

                <label for="telephone">Téléphone :</label>
                <input type="text" name="telephone" id="telephone" value="<?php echo htmlspecialchars($rdv['telephone']); ?>" required>

                <label for="mail">E-mail :</label>
                <input type="email" name="mail" id="mail" value="<?php echo htmlspecialchars($rdv['mail']); ?>" required>

                <label for="adresse">Adresse :</label>
                <input type="text" name="adresse" id="adresse" value="<?php echo htmlspecialchars($rdv['adresse']); ?>" required>

                <label for="ville">Ville :</label>
                <input type="text" name="ville" id="ville" value="<?php echo htmlspecialchars($rdv['ville']); ?>" required>
                
                <label for="code_postal">Code postal :</label>
                <input type="text" name="code_postal" id="code_postal" value="<?php echo htmlspecialchars($rdv['code_postal']); ?>" required>

                <label for="voiture">Voiture :</label>
                <select name="voiture" id="voiture" required>
                    <option value="Ferrari" <?php echo ($rdv['voiture'] == 'Ferrari') ? 'selected' : ''; ?>>Ferrari</option>
                    <option value="McLarren" <?php echo ($rdv['voiture'] == 'McLarren') ? 'selected' : ''; ?>>McLarren</option>
                    <option value="Porche" <?php echo ($rdv['voiture'] == 'Porche') ? 'selected' : ''; ?>>Porche</option>
                    <option value="Maseratti" <?php echo ($rdv['voiture'] == 'Maseratti') ? 'selected' : ''; ?>>Maseratti</option>
                </select>

                <label for="maintenance">Maintenance :</label>
                <select name="maintenance" id="maintenance" required>
                    <option value="Vidange" <?php echo ($rdv['maintenance'] == 'Vidange') ? 'selected' : ''; ?>>Vidange</option>
                    <option value="Révision" <?php echo ($rdv['maintenance'] == 'Révision') ? 'selected' : ''; ?>>Révision</option>
                    <option value="Réparation des pannes mécaniques" <?php echo ($rdv['maintenance'] == 'Réparation des pannes mécaniques') ? 'selected' : ''; ?>>Réparation des pannes mécaniques</option>
                    <option value="Réparations électriques" <?php echo ($rdv['maintenance'] == 'Réparations électriques') ? 'selected' : ''; ?>>Réparations électriques</option>
                </select>

                <label for="date">Date :</label>
                <input type="date" name="date" id="date" value="<?php echo $rdv['date']; ?>" required>

                <label for="description">Description :</label>
                <textarea name="description" id="description" required><?php echo htmlspecialchars($rdv['description']); ?></textarea>

                <button type="submit" name="update" class="btn-primary">Mettre à jour le Rendez-vous</button>
            </form>
            <?php
        }
    }
?>

<!-- Formulaire pour ajouter un nouveau rendez-vous -->
<h3>Ajouter un Rendez-vous</h3>
<form action="" method="POST" class="form-container">
    <label for="sexe">Sexe :</label>
    <select name="sexe" id="sexe" required>
        <option value="Homme">Homme</option>
        <option value="Femme">Femme</option>
    </select>

    <label for="nom">Nom :</label>
    <input type="text" name="nom" id="nom" required>

    <label for="prenom">Prénom :</label>
    <input type="text" name="prenom" id="prenom" required>

    <label for="telephone">Téléphone :</label>
    <input type="text" name="telephone" id="telephone" required>

    <label for="mail">E-mail :</label>
    <input type="email" name="mail" id="mail" required>

    <label for="adresse">Adresse :</label>
    <input type="text" name="adresse" id="adresse" required>

    <label for="ville">Ville :</label>
    <input type="text" name="ville" id="ville" required>

    <label for="code_postal">Code postal :</label>
    <input type="text" name="code_postal" id="code_postal" required>

    <label for="voiture">Voiture :</label>
    <select name="voiture" id="voiture" required>
        <option value="Ferrari">Ferrari</option>
        <option value="McLarren">McLarren</option>
        <option value="Porche">Porche</option>
        <option value="Maseratti">Maseratti</option>
    </select>

    <label for="maintenance">Maintenance :</label>
    <select name="maintenance" id="maintenance" required>
        <option value="Vidange">Vidange</option>
        <option value="Révision">Révision</option>
        <option value="Réparation des pannes mécaniques">Réparation des pannes mécaniques</option>
        <option value="Réparations électriques">Réparations électriques</option>
    </select>

    <label for="date">Date :</label>
    <input type="date" name="date" id="date" required>

    <label for="description">Description :</label>
    <textarea name="description" id="description" required></textarea>

    <button type="submit" class="btn-primary">Ajouter le Rendez-vous</button> |
    <button type="button" onclick="window.location.href='services_dashboard.php';">Retour</button>
</form>



</body>
</html>  
