<?php
// Inclusion du fichier de configuration pour la connexion à la base de données
include_once("config.php");

// Vérification de la présence de l'ID dans l'URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // S'assurer que l'ID est un entier

    // Suppression de l'image dans la base de données
    $query = "DELETE FROM images WHERE id=$id";

    if (mysqli_query($bdd, $query)) {
        // Rediriger vers la page principale avec un message de succès
        header("Location: index.php?message=Image supprimée avec succès");
        exit;
    } else {
        // Affichage d'un message d'erreur en cas de problème
        echo "<font color='red'>Erreur lors de la suppression : " . mysqli_error($bdd) . "</font>";
    }
} else {
    // Rediriger vers la page principale si aucun ID n'est fourni
    header("Location: index.php?message=ID non spécifié");
    exit;
}
?>
