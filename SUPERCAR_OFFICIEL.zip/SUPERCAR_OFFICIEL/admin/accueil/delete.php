<?php
// Inclusion du fichier de configuration pour la connexion à la base de données
include_once("config.php");

// Vérification si l'ID est défini dans l'URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Convertir l'ID en entier pour éviter les erreurs ou les injections

    // Préparer la requête de suppression
    $query = "DELETE FROM accueil1 WHERE id=?";
    $stmt = $bdd->prepare($query);
    $stmt->bind_param("i", $id);

    // Exécuter la requête et vérifier le résultat
    if ($stmt->execute()) {
        // Rediriger vers la page principale avec un message de confirmation
        header("Location: index.php?message=Entrée supprimée avec succès");
        exit;
    } else {
        echo "<font color='red'>Erreur lors de la suppression : " . $bdd->error . "</font>";
    }

    $stmt->close();
} else {
    echo "<font color='red'>L'ID est manquant dans la requête.</font>";
}
?>
