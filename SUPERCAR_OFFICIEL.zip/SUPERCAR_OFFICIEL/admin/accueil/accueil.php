<?php
// Inclusion du fichier de configuration pour la connexion à la base de données
include_once("config.php");
?>
<!DOCTYPE html>
<html lang="fr">
<head>    
    <title>Modifier une entrée</title>
</head>
<body>
    <a href="index.php">Retour à la liste</a>
    <br/><br/>

    <h2>Administration des Images</h2>

    <!-- Tableau pour afficher toutes les images -->
    <table border="1" width="80%">
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
        <?php
        // Récupération de toutes les données de la table
        $resultImages = mysqli_query($bdd, "SELECT * FROM images");
        if (mysqli_num_rows($resultImages) > 0) {
            while ($row = mysqli_fetch_assoc($resultImages)) {
                $imageId = $row['id'];
                $nom = htmlspecialchars($row['nom']);
                $imageBlob = !empty($row['image']) ? base64_encode($row['image']) : null;

                echo "<tr>";
                echo "<td>" . $imageId . "</td>";
                echo "<td>" . $nom . "</td>";
                echo "<td>";
                if ($imageBlob) {
                    echo "<img src='data:image/jpeg;base64,$imageBlob' alt='Image $imageId' width='100'>";
                } else {
                    echo "Aucune image";
                }
                echo "</td>";
                echo "<td>
                        <a href='edit.php?id=$imageId'>Modifier</a> |
                        <a href='delete_image.php?id=$imageId' onclick='return confirm(\"Êtes-vous sûr de vouloir supprimer cette image ?\")'>Supprimer</a>
                      </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Aucune image trouvée.</td></tr>";
        }
        ?>
    </table>
</body>
</html>
