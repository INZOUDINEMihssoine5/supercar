<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}


// Inclure la connexion à la base de données
require_once 'db_connection.php';
?>
<?php
// Inclusion du fichier de configuration pour la connexion à la base de données
include_once("config.php");

// Vérification si l'ID est défini dans l'URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    echo "<font color='red'>L'ID est manquant.</font><br/>";
    exit;
}

// Traitement de la mise à jour de l'entrée dans la table accueil1
if (isset($_POST['update'])) {
    $type = $_POST['type'];
    $nom = $_POST['nom'];  
    $valeur = $_POST['valeur'];

    // Vérifier les champs vides
    if (empty($type) || empty($nom) || empty($valeur)) {            
        if (empty($type)) {
            echo "<font color='red'>Le champ 'Type' est vide.</font><br/>";
        }
        
        if (empty($nom)) {
            echo "<font color='red'>Le champ 'Nom' est vide.</font><br/>";
        }
        
        if (empty($valeur)) {
            echo "<font color='red'>Le champ 'Valeur' est vide.</font><br/>";
        }        
    } else {    
        // Utilisation de requêtes préparées pour éviter les injections SQL
        $query = "UPDATE accueil1 SET type=?, nom=?, valeur=? WHERE id=?";
        $stmt = $bdd->prepare($query);
        $stmt->bind_param("sssi", $type, $nom, $valeur, $id);
        $stmt->execute();
        $stmt->close();
        
        // Rediriger vers la page d'affichage (index.php)
        header("Location: index.php");
        exit;
    }
}

// Récupérer les données associées à cet identifiant dans la table accueil1
$query = "SELECT * FROM accueil1 WHERE id=?";
$stmt = $bdd->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($res = $result->fetch_assoc()) {
    $type = $res['type'];
    $nom = $res['nom'];
    $valeur = $res['valeur'];
}
$stmt->close();

// Récupérer les données de la table images pour affichage
$queryImages = "SELECT * FROM images WHERE id=?";
$stmtImages = $bdd->prepare($queryImages);
$stmtImages->bind_param("i", $id);
$stmtImages->execute();
$resultImages = $stmtImages->get_result();

$image = null;
if ($resultImages->num_rows > 0) {
    $imageData = $resultImages->fetch_assoc();
    $imageId = $imageData['id'];
    $imageName = htmlspecialchars($imageData['nom']);
    $imageBlob = !empty($imageData['image']) ? base64_encode($imageData['image']) : null;
}
$stmtImages->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une entrée</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        /* Styles pour les tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Styles pour les boutons */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #333;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn:hover {
            background-color: #ff0000;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #333;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #ff0000;
        }

        /* Formulaire de modification */
        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
            margin: 20px auto;
        }

        .form-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .form-container input,
        .form-container textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
        }

        /* Lien stylé */
        a {
            color: #333;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    
    
    <form name="form1" method="post" action="edit.php" enctype="multipart/form-data" class="form-container">
        <h2>Modifier l'entrée</h2>
        <table border="1" width="80%">
            <tr> 
                <td>Type</td>
                <td><input type="text" name="type" value="<?php echo htmlspecialchars($type); ?>"></td>
            </tr>
            <tr> 
                <td>Nom</td>
                <td><input type="text" name="nom" value="<?php echo htmlspecialchars($nom); ?>"></td>
            </tr>
            <tr> 
                <td>Valeur</td>
                <td>
                    <textarea name="valeur" rows="5" cols="40" required><?php echo htmlspecialchars($valeur); ?></textarea>
                </td>
            </tr>
        </table>
        <input type="hidden" name="id" value="<?php echo $id; ?>">
        <input type="submit" name="update" value="Mettre à jour" class="btn">

        <br>
        
        <button type="button" onclick="window.location.href='index.php';">Retour</button>
    </form>

    
</body>
</html>
