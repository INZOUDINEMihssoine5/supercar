<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}


// Inclure la connexion à la base de données
require_once 'db_connection.php';
?>
<?php
// Inclure la connexion à la base de données
include_once("config.php");
// Récupération des marques uniques

$sqlMarques = "SELECT DISTINCT marque FROM voitures";
$resultMarques = $db->query($sqlMarques);

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $marque = $_POST['marque'];
    $modele = $_POST['modele'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $statut = $_POST['statut'];

    // Vérification des champs vides
    if (empty($marque) || empty($modele) || empty($name) || empty($phone) || empty($email)) {
        if (empty($marque)) {
            echo "<font color='red'>Le champ marque est vide.</font><br/>";
        }
        if (empty($modele)) {
            echo "<font color='red'>Le champ modèle est vide.</font><br/>";
        }
        if (empty($name)) {
            echo "<font color='red'>Le champ nom est vide.</font><br/>";
        }
        if (empty($phone)) {
            echo "<font color='red'>Le champ téléphone est vide.</font><br/>";
        }
        if (empty($email)) {
            echo "<font color='red'>Le champ email est vide.</font><br/>";
        }
    } else {
        // Mise à jour dans la table
        $result = mysqli_query($bdd, "UPDATE demandes SET 
            marque='$marque', 
            modele='$modele', 
            name='$name', 
            phone='$phone', 
            email='$email', 
            statut='$statut' 
            WHERE id=$id");

        // Redirection vers la page d'affichage (index.php)
        header("Location: index.php");
    }
}
?>

<?php
// Récupérer l'id depuis l'URL
$id = $_GET['id'];

// Sélection des données associées à cet ID
$result = mysqli_query($bdd, "SELECT * FROM demandes WHERE id=$id");

while ($res = mysqli_fetch_array($result)) {
    $marque = $res['marque'];
    $modele = $res['modele'];
    $name = $res['name'];
    $phone = $res['phone'];
    $email = $res['email'];
    $statut = $res['statut'];
}
?>

<html>
<head>    
    <title>Modifier une Demande</title>
    <style>/* Styles généraux */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

h1, h2 {
    color: #333;
    margin-bottom: 20px;
    text-align: center;
}

.container {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 800px;
    margin-bottom: 20px;
}

/* Styles pour les tables */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}

table th, table td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
}

table th {
    background-color: #f0f0f5;
    font-weight: bold;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

tr:hover {
    background-color: #f1f1f1;
}

/* Styles pour les boutons */
.btn {
    display: inline-block;
    padding: 10px 20px;
    background-color: rgb(0, 0, 0);
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-size: 16px;
    transition: background-color 0.3s;
    text-align: center;
}

.btn:hover {
    background-color: rgb(255, 0, 0);
}

button {
    width: 100%;
    padding: 12px;
    background-color: rgb(0, 0, 0);
    border: none;
    border-radius: 5px;
    color: white;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: rgb(255, 0, 0);
}

/* Formulaire de connexion */
.login-container {
    background-color: #ffffff;
    padding: 40px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
    text-align: center;
    margin: 20px auto;
}

.login-container label {
    display: block;
    font-size: 14px;
    margin-bottom: 5px;
    text-align: left;
    margin-left: 10px;
}

.login-container input {
    width: 100%;
    padding: 12px;
    margin: 10px 0 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 16px;
}

.error-message {
    color: red;
    margin-bottom: 20px;
}

/* Lien stylé */
a {
    color: black;
    text-decoration: none;
    font-size: 14px;
}

a:hover {
    text-decoration: underline;
}
</style>
</head>

<body>
    

<div class="container">
    <h1>Formulaire de Mise à Jour</h1>

    <form name="form1" method="post" action="edit.php">
        <table border="0">
            <tr>
                <td><label for="marque">Marque</label></td>
                <td>
                    <select name="marque" id="marque">
                    <option value="" disabled selected>Choisissez une marque</option>
                        <?php while ($row = $resultMarques->fetch(PDO::FETCH_ASSOC)) : ?>
                            <option value="<?= htmlspecialchars($row['marque']); ?>"> <?= htmlspecialchars($row['marque']); ?> </option>
                        <?php endwhile; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="modele">Modèle</label></td>
                <td>
                    <select name="modele" id="modele">
                        <option value="">Sélectionnez une marque d'abord</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="phone">Téléphone</label></td>
                <td><input type="text" name="phone" value="<?php echo $phone; ?>" id="phone"></td>
            </tr>
            <tr>
                <td><label for="email">Email</label></td>
                <td><input type="text" name="email" value="<?php echo $email; ?>" id="email"></td>
            </tr>
            <tr>
                <td><label for="statut">Statut</label></td>
                <td>
                    <select name="statut" id="statut">
                        <option value="En attente" <?php echo ($statut == 'En attente') ? 'selected' : ''; ?>>En attente</option>
                        <option value="Approuvé" <?php echo ($statut == 'Approuvé') ? 'selected' : ''; ?>>Approuvé</option>
                        <option value="Rejeté" <?php echo ($statut == 'Rejeté') ? 'selected' : ''; ?>>Rejeté</option>
                    </select>
                </td>
            </tr>
        </table>

        <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
        
        <div class="button-group">
            <button type="submit" name="update">Mettre à jour</button>
            <button type="button" onclick="window.location.href='index.php';">Retour</button>
        </div>
    </form>
</div>

<script>
    document.getElementById('marque').addEventListener('change', function() {
        var marque = this.value;
        var modeleSelect = document.getElementById('modele');

        if (!marque) {
            modeleSelect.innerHTML = '<option value="">Sélectionnez une marque d\'abord</option>';
            return;
        }

        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'get_modeles.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                modeleSelect.innerHTML = xhr.responseText;
            }
        };

        xhr.send('marque=' + encodeURIComponent(marque));
    });
</script>

</body>
</html>