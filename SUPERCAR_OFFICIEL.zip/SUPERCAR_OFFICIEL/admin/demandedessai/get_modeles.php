<?php
// Paramètres de connexion à la base de données
$host = 'localhost';      // Hôte de la base de données
$dbname = 'supercar'; // Remplacez par le nom de votre base de données
$user = 'root';     // Nom d'utilisateur de la base de données
$password = '';  // Mot de passe de la base de données

try {
    // Connexion à la base de données avec PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Vérifie si la marque a été envoyée
if (isset($_POST['marque'])) {
    $marque = $_POST['marque'];

    // Requête SQL pour récupérer les modèles en fonction de la marque
    $sql = "SELECT DISTINCT modele FROM voitures WHERE marque = :marque";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['marque' => $marque]);
    $modeles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($modeles) {
        // Génère les options HTML pour les modèles
        foreach ($modeles as $modele) {
            echo '<option value="' . htmlspecialchars($modele['modele']) . '">' . htmlspecialchars($modele['modele']) . '</option>';
        }
    } else {
        echo '<option value="">Aucun modèle trouvé</option>';
    }
} else {
    echo '<option value="">Aucune marque sélectionnée</option>';
}
?>
