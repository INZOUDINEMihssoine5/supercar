<?php
// Inclusion du fichier de configuration pour la connexion à la base de données
include_once("config.php");

// Vérification si l'ID est passé dans l'URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Sécurisation de l'ID

    // Préparation de la requête de suppression
    $query = "DELETE FROM demandes WHERE id=?";
    $stmt = $bdd->prepare($query);
    $stmt->bind_param("i", $id);

    // Exécution de la requête
    if ($stmt->execute()) {
        // Redirection vers la page d'affichage avec un message de confirmation
        header("Location: index.php?message=Demande supprimée avec succès");
        exit;
    } else {
        echo "<font color='red'>Erreur lors de la suppression : " . $bdd->error . "</font>";
    }

    $stmt->close();
} else {
    echo "<font color='red'>L'ID est manquant dans la requête.</font>";
}
?>
