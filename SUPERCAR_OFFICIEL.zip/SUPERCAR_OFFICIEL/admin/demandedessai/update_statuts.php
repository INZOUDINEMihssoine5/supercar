<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/supercar/admin/config.php");

// Debugging: Écrire dans un fichier pour voir les requêtes reçues
file_put_contents("debug_log.txt", "Reçu : ID=" . $_POST['id'] . " | Statut=" . $_POST['statut'] . "\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id']);
    $statut = $_POST['statut'];

    // Vérifier les valeurs reçues
    if (!$id || empty($statut)) {
        die("Erreur : Données manquantes");
    }

    // Vérifier que le statut est valide
    $valid_statuses = ['Confirmé', 'Terminé', 'Annulé'];
    if (!in_array($statut, $valid_statuses)) {
        die("Erreur : Statut invalide");
    }

    // Vérifier la connexion à la base
    if (!$bdd) {
        die("Erreur de connexion : " . mysqli_connect_error());
    }

    // Mettre à jour la base de données
    $stmt = $bdd->prepare("UPDATE demandes_essai SET statut=? WHERE id=?");
    $stmt->bind_param("si", $statut, $id);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "Erreur SQL : " . $stmt->error;
    }
}
?>
