<?php
session_start();

// Vérification de la session admin
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

// Connexion à la base de données
require_once 'db_connection.php';

// Récupération des marques uniques
$sqlMarques = "SELECT DISTINCT marque FROM voitures";
$resultMarques = $db->query($sqlMarques);

// Vérification si le formulaire est soumis
if (isset($_POST['add'])) {
    $marque = $_POST['marque'] ?? '';
    $modele = $_POST['modele'] ?? '';
    $name = $_POST['name'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $email = $_POST['email'] ?? '';
    $statut = $_POST['statut'] ?? 'En attente';

    // Vérification des champs vides
    $errors = [];
    if (empty($marque)) $errors[] = "Le champ marque est vide.";
    if (empty($modele)) $errors[] = "Le champ modèle est vide.";
    if (empty($name)) $errors[] = "Le champ nom est vide.";
    if (empty($phone)) $errors[] = "Le champ téléphone est vide.";
    if (empty($email)) $errors[] = "Le champ email est vide.";

    if (count($errors) > 0) {
        foreach ($errors as $error) {
            echo "<font color='red'>" . htmlspecialchars($error) . "</font><br/>";
        }
    } else {
        // Insertion des données dans la table
        $query = "INSERT INTO demandes (marque, modele, name, phone, email, statut) VALUES (:marque, :modele, :name, :phone, :email, :statut)";
        $stmt = $pdo->prepare($query);

        if ($stmt->execute([
            ':marque' => $marque,
            ':modele' => $modele,
            ':name' => $name,
            ':phone' => $phone,
            ':email' => $email,
            ':statut' => $statut
        ])) {
            header("Location: index.php?message=Demande ajoutée avec succès");
            exit;
        } else {
            echo "<font color='red'>Erreur lors de l'ajout.</font>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Demande</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .form-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        select, input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            padding: 12px;
            background-color: #000;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: red;
        }
    </style>
</head>
<body>
    <h2>Ajouter une nouvelle demande</h2>
    <form method="post" action="add.php" class="form-container">
        <label for="marque">Marque</label>
        <select name="marque" id="marque">
        <option value="" disabled selected>Choisissez une marque</option>
            <?php while ($row = $resultMarques->fetch(PDO::FETCH_ASSOC)) : ?>
                <option value="<?= htmlspecialchars($row['marque']); ?>"> <?= htmlspecialchars($row['marque']); ?> </option>
            <?php endwhile; ?>
        </select>

        <label for="modele">Modèle</label>
        <select name="modele" id="modele">
            <option value="">Sélectionnez une marque d'abord</option>
        </select>

        <label for="name">Nom complet</label>
        <input type="text" name="name" required>

        <label for="phone">Téléphone</label>
        <input type="text" name="phone" required>

        <label for="email">Email</label>
        <input type="email" name="email" required>

        <label for="statut">Statut</label>
        <select name="statut">
            <option value="En attente">En attente</option>
            <option value="Approuvé">Approuvé</option>
            <option value="Rejeté">Rejeté</option>
        </select>

        <button type="submit" name="add">Ajouter</button>
        <button type="button" onclick="window.location.href='index.php';">Retour</button>
    </form>

    <script>
        document.getElementById('marque').addEventListener('change', function() {
            var marque = this.value;
            var modeleSelect = document.getElementById('modele');

            if (!marque) {
                modeleSelect.innerHTML = '<option value="">Sélectionnez une marque d\'abord</option>';
                return;
            }

            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'get_modeles.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    modeleSelect.innerHTML = xhr.responseText;
                }
            };

            xhr.send('marque=' + encodeURIComponent(marque));
        });
    </script>
</body>
</html>
