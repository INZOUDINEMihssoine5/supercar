<?php
// Inclusion de la connexion à la base de données
include_once($_SERVER['DOCUMENT_ROOT'] . "/demandedessai/admin/config.php");

// Récupération des données de la table "demandes" par ordre croissant d'ID
$result = mysqli_query($bdd, "SELECT * FROM demandes ORDER BY id ASC");
?>

<html>
<head>    
    <title>Gestion des Demandes</title>
    <style>
        /* Styles pour centrer le contenu */
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
        }

        /* Styles pour le titre */
        p {
            margin-bottom: 20px;
            font-weight: bold;
            font-size: 1.5em;
            text-align: center;
        }

        /* Styles pour le tableau */
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 0 auto;
            background-color: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        th {
            padding-top: 12px;
            padding-bottom: 12px;
            background-color: #4CAF50;
            color: white;
        }

        a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <p>Gestion des Demandes</p>
	
    <table>
        <tr>
            <th>ID</th>
            <th>Modèle</th>
            <th>Nom</th>
            <th>Téléphone</th>
            <th>Email</th>
            <th>Commentaires</th>
            <th>Action</th>
        </tr>
		
        <?php 
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['id']."</td>";
            echo "<td>".$res['model']."</td>";
            echo "<td>".$res['name']."</td>";
            echo "<td>".$res['phone']."</td>";
            echo "<td>".$res['email']."</td>";
            echo "<td>".$res['comments']."</td>";    
            echo "<td>
                    <a href=\"edit.php?id=$res[id]\">Modifier</a> | 
                    <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Êtes-vous sûr de vouloir supprimer cette demande ?')\">Supprimer</a>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
    <br>
    <a href="/demandedessai/dashboard.php">Retour au Tableau de Bord</a>
</body>
</html>
