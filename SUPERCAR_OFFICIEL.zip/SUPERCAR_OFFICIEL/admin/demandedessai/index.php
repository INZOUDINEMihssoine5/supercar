<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

// Vérification si l'utilisateur est un administrateur
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}

// Inclure la connexion à la base de données (connexion PDO)
require_once 'db_connection.php'; // Le fichier de connexion avec PDO


// Vérifier que la connexion PDO fonctionne
if (!$db) {
    die("Erreur de connexion à la base de données.");
}

// Récupérer les demandes depuis la base de données avec PDO
$query = $db->prepare("SELECT * FROM demandes ORDER BY id ASC");
$query->execute();
$result = $query->fetchAll(PDO::FETCH_ASSOC); // Récupérer les résultats sous forme de tableau associatif

// Si aucune demande n'est trouvée
if (!$result) {
    die("Aucune demande trouvée.");
}
?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Demandes</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        /* Styles pour les tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Styles pour les boutons */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0, 0, 0);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn:hover {
            background-color: rgb(255, 0, 0);
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: rgb(0, 0, 0);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgb(255, 0, 0);
        }

        /* Formulaire de connexion */
        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            margin: 20px auto;
        }

        .login-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
        }

        /* Lien stylé */
        a {
            color: black;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<h2>Gestion des demandes</h2>

<table border="1" width="100%">
    <tr>
        <th>ID</th>
        <th>Marque</th>
        <th>Modèle</th>
        <th>Nom</th>
        <th>Téléphone</th>
        <th>Email</th>
        <th>Statut</th>
        <th>Actions</th>
    </tr>
    <?php
    // Afficher les demandes récupérées depuis la base de données
    foreach ($result as $row) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['marque']) . "</td>";
        echo "<td>" . htmlspecialchars($row['modele']) . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['phone']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td>" . htmlspecialchars($row['statut']) . "</td>";
        echo "<td>
                <a href='edit.php?id=" . $row['id'] . "' class='btn'>Modifier</a> |
                <a href='delete.php?id=" . $row['id'] . "' class='btn' onclick='return confirm(\"Êtes-vous sûr de vouloir supprimer cette demande ?\")'>Supprimer</a> 
              </td>";
        echo "</tr>";
    }
    ?>
</table>

<button type="button" onclick="window.location.href='add.php';">Ajouter</button>
<button type="button" onclick="window.location.href='../dashboard.php';">Retour</button>

</body>
</html>
