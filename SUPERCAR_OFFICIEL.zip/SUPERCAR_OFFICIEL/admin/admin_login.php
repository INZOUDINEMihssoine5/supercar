<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $serveur = "mysql-supercar.alwaysdata.net";
    $utilisateur = "supercar";
    $mot_de_passe = "Jr.Pictures97640";
    $base_de_donnees = "supercar_web";

    // Connexion à la base de données
    $connexion = new mysqli($serveur, $utilisateur, $mot_de_passe, $base_de_donnees);

    // Vérifier la connexion
    if ($connexion->connect_error) {
        die("Échec de la connexion à la base de données : " . $connexion->connect_error);
    }

    // Échapper les entrées utilisateur pour éviter les injections SQL
    $username = $connexion->real_escape_string($_POST['username']);
    $password = $connexion->real_escape_string($_POST['password']);

    // Requête SQL pour vérifier les identifiants
    $requete = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
    $resultat = $connexion->query($requete);


    if ($resultat->num_rows > 0) {
            // Connexion réussie, démarrer la session
            $_SESSION['admin'] = $username;
    
            // Enregistrer la connexion dans la table "connections"
            $sql_log = "INSERT INTO connections (username) VALUES ('$username')";
            if (!$connexion->query($sql_log)) {
                die("Erreur lors de l'enregistrement de la connexion : " . $connexion->error);
            }

        // Rediriger vers la page précédente ou tableau de bord par défaut
        $redirect_url = $_SESSION['redirect_to'] ?? 'dashboard.php';
        unset($_SESSION['redirect_to']); // Nettoyer la session de redirection
        header("Location: $redirect_url");
        exit();
    } else {
        // Identifiants incorrects
        $error = "Identifiant ou mot de passe incorrect.";
    }

    // Fermer la connexion
    $connexion->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
</head>
<style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .login-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .login-container button {
            width: 100%;
            padding: 12px;
            background-color:rgb(0, 0, 0);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .login-container button:hover {
            background-color:rgb(255, 0, 0);
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
        }

        .login-container a {
            color:rgb(255, 255, 255);
            text-decoration: none;
            font-size: 14px;
            display: block;
            margin-top: 10px;
        }

        .login-container a:hover {
            text-decoration: underline;
        }
    </style>
<body>
<div class="login-container">
    <h2>Connexion Administrateur</h2>
    <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form action="" method="post">
        <label for="username">Nom d'utilisateur :</label>
        <input type="text" name="username" id="username" required>
        
        <label for="password">Mot de passe :</label>
        <input type="password" name="password" id="password" required>
        
        <button type="submit">Se connecter</button> |
        <button> <a href="../accueil.php">Quitter</a> </button>

    </form>
    
    </div>
</body>
</html>
