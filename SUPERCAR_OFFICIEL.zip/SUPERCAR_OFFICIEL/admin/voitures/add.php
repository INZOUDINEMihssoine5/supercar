<?php
session_start();

// Vérifier si l'utilisateur est administrateur
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

require_once 'db_connection1.php';


// Traitement de l'ajout de la voiture
if (isset($_POST['add'])) {
    // Récupération des informations du formulaire
    $marque = $_POST['marque'];
    $modele = $_POST['modele'];
    $description = $_POST['description'];
    $prix = $_POST['prix'];
    $vitesseMax = $_POST['vitesse_max'];
    $puissance = $_POST['puissance'];

    // Vérification des champs obligatoires
    if (empty($marque) || empty($modele) || empty($description) || empty($prix) || empty($vitesseMax) || empty($puissance)) {
        echo "<font color='red'>Tous les champs marqués * sont obligatoires.</font><br/>";
    } else {
        // Insertion des informations de la voiture dans la table 'voitures'
        $query = "INSERT INTO voitures (marque, modele, description, prix, vitesse_max, puissance) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        
        $stmt = $bd->prepare($query);
        $stmt->bind_param("ssssss", $marque, $modele, $description, $prix, $vitesseMax, $puissance);

        if ($stmt->execute()) {
            // Après avoir inséré les informations de la voiture, obtenir l'ID de la voiture ajoutée
            $voitureId = $stmt->insert_id;  // ID de la voiture qui a été insérée

            // Traitement de l'image si elle est téléchargée
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $imageName = $_FILES['image']['name'];
                $imageTmpName = $_FILES['image']['tmp_name'];

                // Lire le contenu de l'image en tant que BLOB
                $imageData = file_get_contents($imageTmpName);

                // Insertion de l'image dans la table 'images'
                $imageQuery = "INSERT INTO images (nom, image, modele) VALUES (?, ?, ?)";
                $imgStmt = $bd->prepare($imageQuery);
                $imgStmt->bind_param("sss", $imageName, $imageData, $modele); // Utilisation du modèle pour lier l'image à la voiture

                if (!$imgStmt->execute()) {
                    echo "<font color='red'>Erreur lors de l'ajout de l'image : " . $bd->error . "</font>";
                    exit;
                }
                $imgStmt->close();
            }

            // Rediriger avec un message de succès
            header("Location: index.php?message=Voiture ajoutée avec succès");
            exit;
        } else {
            echo "<font color='red'>Erreur lors de l'ajout de la voiture : " . $bd->error . "</font>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Voiture</title>
    <style>
        body { font-family: 'Arial', sans-serif; background-color: #f4f4f9; padding: 20px; display: flex; justify-content: center; }
        .form-container { background: #fff; padding: 40px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); width: 100%; max-width: 600px; }
        label { display: block; margin: 10px 0 5px; }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 12px; background: black; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: red; }
    </style>
</head>
<body>
    <form method="post" action="add.php" enctype="multipart/form-data" class="form-container">
        <label for="marque">Marque *</label>
        <input type="text" name="marque" required>

        <label for="modele">Modèle *</label>
        <input type="text" name="modele" required>

        <label for="description">Description *</label>
        <input type="text" name="description" required>

        <label for="prix">Prix (€) *</label>
        <input type="number" name="prix" step="0.01" required>

        <label for="vitesse_max">Vitesse Max (km/h) *</label>
        <input type="number" name="vitesse_max" required>

        <label for="puissance">Puissance (ch) *</label>
        <input type="number" name="puissance" required>

        <label for="image">Image de la voiture</label>
        <input type="file" name="image" accept="image/*">

        <button type="submit" name="add">Ajouter</button>
        <button type="button" onclick="window.location.href='index.php';">Retour</button>
    </form>
</body>
</html>
