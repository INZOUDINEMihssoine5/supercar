<?php
session_start();

// Vérifier si l'utilisateur est administrateur
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();
}

require_once 'db_connection1.php'; // Inclure le fichier de connexion à la base de données

// Vérifier si l'ID de la voiture est passé en paramètre
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<font color='red'>ID de la voiture manquant.</font>";
    exit;
}

$voitureId = $_GET['id']; // Récupérer l'ID de la voiture à modifier

// Récupérer les informations de la voiture à modifier
$query = "SELECT * FROM voitures WHERE id = ?";
$stmt = $bd->prepare($query);
$stmt->bind_param("i", $voitureId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<font color='red'>Voiture non trouvée.</font>";
    exit;
}

$voiture = $result->fetch_assoc();
$stmt->close();

// Récupérer l'image associée à la voiture
$imageQuery = "SELECT * FROM images WHERE modele = ?";
$imageStmt = $bd->prepare($imageQuery);
$imageStmt->bind_param("s", $voiture['modele']);
$imageStmt->execute();
$imageResult = $imageStmt->get_result();
$imageData = null;

if ($imageResult->num_rows > 0) {
    $imageData = $imageResult->fetch_assoc();
}
$imageStmt->close();

// Traitement du formulaire d'édition
if (isset($_POST['update'])) {
    // Récupération des nouvelles valeurs du formulaire
    $marque = $_POST['marque'];
    $modele = $_POST['modele'];
    $description = $_POST['description'];
    $prix = $_POST['prix'];
    $vitesseMax = $_POST['vitesse_max'];
    $puissance = $_POST['puissance'];

    // Mise à jour des informations de la voiture
    $updateQuery = "UPDATE voitures SET marque = ?, modele = ?, description = ?, prix = ?, vitesse_max = ?, puissance = ? WHERE id = ?";
    $updateStmt = $bd->prepare($updateQuery);
    $updateStmt->bind_param("ssssssi", $marque, $modele, $description, $prix, $vitesseMax, $puissance, $voitureId);

    if ($updateStmt->execute()) {
        // Si une nouvelle image est téléchargée, on la met à jour aussi
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $imageName = $_FILES['image']['name'];
            $imageTmpName = $_FILES['image']['tmp_name'];
            $imageData = file_get_contents($imageTmpName); // Lire l'image en tant que BLOB

            // Mise à jour de l'image dans la table 'images'
            if ($imageData) {
                $imageUpdateQuery = "UPDATE images SET nom = ?, image = ? WHERE modele = ?";
                $imageUpdateStmt = $bd->prepare($imageUpdateQuery);
                $imageUpdateStmt->bind_param("sss", $imageName, $imageData, $modele);

                if (!$imageUpdateStmt->execute()) {
                    echo "<font color='red'>Erreur lors de la mise à jour de l'image.</font>";
                    exit;
                }

                $imageUpdateStmt->close();
            }
        }

        // Rediriger après une mise à jour réussie
        header("Location: index.php?message=Voiture mise à jour avec succès");
        exit;
    } else {
        echo "<font color='red'>Erreur lors de la mise à jour de la voiture : " . $bd->error . "</font>";
    }

    $updateStmt->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Voiture</title>
    <style>
        body { font-family: 'Arial', sans-serif; background-color: #f4f4f9; padding: 20px; display: flex; justify-content: center; }
        .form-container { background: #fff; padding: 40px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); width: 100%; max-width: 600px; }
        label { display: block; margin: 10px 0 5px; }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 12px; background: black; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: red; }
    </style>
</head>
<body>
    <form method="post" action="edit.php?id=<?php echo $voitureId; ?>" enctype="multipart/form-data" class="form-container">
        <label for="marque">Marque *</label>
        <input type="text" name="marque" value="<?php echo $voiture['marque']; ?>" required>

        <label for="modele">Modèle *</label>
        <input type="text" name="modele" value="<?php echo $voiture['modele']; ?>" required>

        <label for="description">Description *</label>
        <input type="text" name="description" value="<?php echo $voiture['description']; ?>" required>

        <label for="prix">Prix (€) *</label>
        <input type="number" name="prix" step="0.01" value="<?php echo $voiture['prix']; ?>" required>

        <label for="vitesse_max">Vitesse Max (km/h) *</label>
        <input type="number" name="vitesse_max" value="<?php echo $voiture['vitesse_max']; ?>" required>

        <label for="puissance">Puissance (ch) *</label>
        <input type="number" name="puissance" value="<?php echo $voiture['puissance']; ?>" required>

        <label for="image">Image de la voiture</label>
        <?php if ($imageData) { ?>
            <img src="data:image/jpeg;base64,<?php echo base64_encode($imageData['image']); ?>" alt="Image de la voiture" style="max-width: 200px; max-height: 150px;">
        <?php } ?>
        <input type="file" name="image" accept="image/*">

        <button type="submit" name="update">Mettre à jour</button>
        <button type="button" onclick="window.location.href='index.php';">Retour</button>
    </form>
</body>
</html>
