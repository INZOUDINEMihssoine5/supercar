<?php
// Paramètres de connexion à la base de données
$host = 'localhost';  // Votre hôte, généralement localhost
$username = 'root';   // Votre nom d'utilisateur MySQL
$password = '';       // Votre mot de passe MySQL
$dbname = 'supercar'; // Le nom de votre base de données

// Créer la connexion à la base de données
$bd = new mysqli($host, $username, $password, $dbname);

// Vérifier la connexion
if ($bd->connect_error) {
    die("La connexion à la base de données a échoué : " . $bd->connect_error);
}
?>
