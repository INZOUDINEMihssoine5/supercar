<?php
session_start(); // Démarre la session si ce n'est pas déjà fait

if (!isset($_SESSION['admin'])) {
    header("Location: ../admin_login.php");
    exit();  // Arrête l'exécution du script après la redirection
}

// Inclure la connexion à la base de données
require_once 'db_connection.php';
?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des voitures</title>
    <style>
        /* Styles généraux */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1, h2 {
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
            margin-bottom: 20px;
        }

        /* Styles pour les tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f5;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        /* Styles pour les boutons */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(0, 0, 0);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            text-align: center;
        }

        .btn:hover {
            background-color: rgb(255, 0, 0);
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: rgb(0, 0, 0);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: rgb(255, 0, 0);
        }

        /* Formulaire de connexion */
        .login-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            margin: 20px auto;
        }

        .login-container label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            text-align: left;
            margin-left: 10px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
        }

        /* Lien stylé */
        a {
            color: black;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
<h2>Administration des Voitures</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Marque</th>
        <th>Modèle</th>
        <th>Description</th>
        <th>Prix</th>
        <th>Vitesse Max</th>
        <th>Puissance</th>
        <th>Image</th>
        <th>Nombre de Vues</th>
        <th>Actions</th>
    </tr>

    <?php
    // Récupération des données des voitures avec jointure sur les images
    $stmt = $db->query("SELECT v.*, i.image AS image_blob FROM voitures v LEFT JOIN images i ON v.modele = i.modele");
    $voitures = $stmt->fetchAll(PDO::FETCH_ASSOC); // Récupérer les données sous forme de tableau associatif

    // Vérifier si des données existent pour les voitures
    if (count($voitures) > 0) {
        // Boucle pour afficher les voitures
        foreach ($voitures as $row) {
            $voitureId = $row['id'];
            $marque = htmlspecialchars($row['marque']);
            $modele = htmlspecialchars($row['modele']);
            $description = htmlspecialchars($row['description']);
            $prix = htmlspecialchars($row['prix']);
            $vitesseMax = htmlspecialchars($row['vitesse_max']);
            $puissance = htmlspecialchars($row['puissance']);
            $imageBlob = $row['image_blob']; // L'image de la table 'images'
            $nbVue = htmlspecialchars($row['nb_vue']);

            echo "<tr>";
            echo "<td>" . $voitureId . "</td>";
            echo "<td>" . $marque . "</td>";
            echo "<td>" . $modele . "</td>";
            echo "<td>" . $description . "</td>";
            echo "<td>" . $prix . "</td>";
            echo "<td>" . $vitesseMax . "</td>";
            echo "<td>" . $puissance . "</td>";
        
            // Affichage de l'image de la voiture si elle existe dans la table 'images'
            echo "<td>";
            if (!empty($imageBlob)) {
                // Convertir l'image en base64 pour l'afficher
                $imageData = base64_encode($imageBlob);
                echo "<img src='data:image/jpeg;base64,$imageData' alt='Image de $marque $modele' style='width: 100px; height: auto;'>";
            } else {
                echo "Aucune image";
            }
            echo "</td>";

            echo "<td>" . $nbVue . "</td>";
            echo "<td>
                    <a href='edit.php?id=$voitureId'>Modifier</a> |
                    <a href='delete.php?id=$voitureId' onclick='return confirm(\"Êtes-vous sûr de vouloir supprimer cette voiture ?\")'>Supprimer</a>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='10'>Aucune voiture trouvée.</td></tr>";
    }
    ?>
</table>

<button type="button" onclick="window.location.href='add.php';">Ajouter</button>
<button type="button" onclick="window.location.href='../dashboard.php';">Retour</button>

</body>
</html>
