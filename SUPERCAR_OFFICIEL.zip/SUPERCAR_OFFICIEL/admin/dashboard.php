<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['admin'])) {
    // Rediriger vers la page de connexion si non connecté
    $_SESSION['redirect_to'] = $_SERVER['REQUEST_URI']; // Sauvegarder la page actuelle
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Admin</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to right, #f0f0f5, #e0e0ff); /* Couleur de fond douce */
    }

    header {
        background-color: black; /* Fond noir pour l'en-tête */
        color: white; /* Texte en blanc */
        padding: 10px 20px;
        text-align: center;
    }

    nav {
        margin: 20px;
        text-align: center;
    }

    nav a {
        text-decoration: none;
        color: black; /* Noir pour les liens */
        margin: 0 15px;
        font-weight: bold;
    }

    nav a:hover {
        color: #FF0000; /* Rouge au survol */
    }

    h2 {
        text-align: center;
        margin: 20px 0;
    }

    .button-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
        margin-top: 50px;
    }

    .button {
        width: 200px;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
        font-size: 18px;
        text-decoration: none;
        color: white; /* Texte blanc */
        background-color: black; /* Fond noir pour les boutons */
        border-radius: 15px;
        text-align: center;
        border: none;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    .button:hover {
        background-color: #FF0000; /* Rouge au survol */
        transform: scale(1.05); /* Effet zoom au survol */
    }
</style>

</head>
<body>
<header>
    <h1>Bienvenue dans le Tableau de Bord <br/> <?php echo htmlspecialchars($_SESSION['admin']); ?></h1>
</header>
<nav>
    <a href="admin_logout.php">Déconnexion</a>
</nav>

<div class="button-container">
<p>
    <a href="accueil/index.php" class="button">Accueil</a> </br>
    <a href="demandedessai/index.php" class="button">Demande d'essai</a>
</p>
<p>
    <a href="voitures/index.php" class="button">Voitures</a></br>
    <a href="services/services_dashboard.php" class="button">Services</a>
</p>
<p>
    <a href="contact/index.php" class="button">Contact</a></br>
    <a href="utilisateurs/index.php" class="button">Utilisateurs</a>
</p>
<p>
    <a href="images/gestion_images.php" class="button">Gestion d'Images</a></br>
    
</p>
</div>

</body>
</html>
