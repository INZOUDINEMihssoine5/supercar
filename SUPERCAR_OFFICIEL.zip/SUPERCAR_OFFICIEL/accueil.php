<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SUPERCAR - Accueil</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<header>
    <?php include 'header.php'; ?>
</header>
<br><br><br>

<!-- Connexion à la base de données -->
<?php
$conn = new mysqli("mysql-supercar.alwaysdata.net", "supercar", "Jr.Pictures97640", "supercar_web");
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}
$conn->set_charset("utf8");
?>

<!-- Conteneur du carrousel -->
<div class="carousel-container">
<?php
$query = "SELECT image FROM images WHERE type = 'carrousel'";
$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $imageData = base64_encode($row['image']);
        echo '<div class="carousel-slide fade">';
        echo '<img src="data:image/jpeg;base64,' . $imageData . '" alt="Image">';
        echo '</div>';
    }
} else {
    echo "<p>Aucune image disponible pour le carrousel.</p>";
}
?>

    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>

<!-- Points de navigation -->
<div class="dot-container">
<?php
$query = "SELECT COUNT(*) as count FROM images WHERE type = 'carrousel'";
$result = $conn->query($query);

if ($result) {
    $row = $result->fetch_assoc();
    $imageCount = $row['count'];
    for ($i = 1; $i <= $imageCount; $i++) {
        echo '<span class="dot" onclick="currentSlide(' . $i . ')"></span>';
    }
}
?>
</div>

<script>
    let slideIndex = 1;
    showSlides(slideIndex);

    function plusSlides(n) {
        showSlides(slideIndex += n);
    }

    function currentSlide(n) {
        showSlides(slideIndex = n);
    }

    function showSlides(n) {
        const slides = document.getElementsByClassName("carousel-slide");
        const dots = document.getElementsByClassName("dot");

        if (slides.length === 0) return;

        if (n > slides.length) { slideIndex = 1; }
        if (n < 1) { slideIndex = slides.length; }

        for (let slide of slides) {
            slide.style.display = "none";
        }

        for (let dot of dots) {
            dot.className = dot.className.replace(" active", "");
        }

        slides[slideIndex - 1].style.display = "block";
        if (dots[slideIndex - 1]) dots[slideIndex - 1].className += " active";
    }

    let autoIndex = 0;
    function autoShowSlides() {
        const slides = document.getElementsByClassName("carousel-slide");
        const dots = document.getElementsByClassName("dot");

        if (slides.length === 0) return;

        for (let slide of slides) {
            slide.style.display = "none";
        }

        autoIndex++;
        if (autoIndex > slides.length) { autoIndex = 1; }

        slides[autoIndex - 1].style.display = "block";
        for (let dot of dots) {
            dot.className = dot.className.replace(" active", "");
        }
        if (dots[autoIndex - 1]) dots[autoIndex - 1].className += " active";

        setTimeout(autoShowSlides, 5000);
    }
    autoShowSlides();
</script>

<section class="cta">
<?php
$query = "SELECT nom, valeur FROM accueil1 WHERE nom IN ('Titre(h2)', 'description supercar')";
$result = $conn->query($query);

if ($result) {
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[$row['nom']] = $row['valeur'];
    }

    echo isset($data['Titre(h2)']) ? "<h2>" . htmlspecialchars($data['Titre(h2)']) . "</h2>" : "<h2>Titre non disponible</h2>";
    echo isset($data['description supercar']) ? "<p>" . htmlspecialchars($data['description supercar']) . "</p>" : "<p>Description non disponible</p>";
} else {
    echo "Erreur dans la requête SQL : " . $conn->error;
}
$conn->close();
?>
    <hr>
    <a href="voitures.php">Explorez notre collection</a>
</section>
<br>
<?php include 'footer.html'; ?>
</body>

</html>
